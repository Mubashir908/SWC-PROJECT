public class CarUpdateEvent extends java.util.EventObject
{

	public CarUpdateEvent(Object source)
	{
		super(source);
	}
}
